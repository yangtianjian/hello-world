package com.company;

import javax.swing.plaf.nimbus.State;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.*;

/**
 * Created by apple on 2017/4/19.
 */
public class SqlManager {
    public String url, user, password;
    public Connection conn = null;

    public SqlManager(String url, String user, String password){
        this.url = url;
        this.user = user;
        this.password = password;
    }

    public void connect(){
        try{
            conn = DriverManager.getConnection(url, user, password);
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public ResultSet query(String sql){
        ResultSet rs = null;
        try {
            Statement statement = conn.createStatement();
            rs = statement.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static Vector<Vector<Object>> resultsetToArray(ResultSet rs){
        Vector<Vector<Object>> ret = new Vector<>();
        int r = 0, c;
        try {
            ResultSetMetaData rsm = rs.getMetaData();
            c = rsm.getColumnCount();
            Vector<Object> pVec = new Vector<>();
            for(int i = 0; i < c; i++){
                pVec.add(rsm.getColumnName(i + 1));
            }
            ret.add((Vector<Object>)pVec.clone());
            while(rs.next()){
                pVec.clear();
                for(int i = 0; i < c; i++){
                    pVec.add(rs.getObject(i + 1));
                }
                ret.add((Vector<Object>)pVec.clone());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return ret;
    }

    public static void print_result(Vector<Vector<Object>> res){
        int[] max_strlen = new int[res.elementAt(0).size()];
        for(Vector<Object> row: res){
            for(int i = 0; i < row.size(); i++){
                max_strlen[i] = Math.max(max_strlen[i], row.elementAt(i).toString().length());
            }
        }
        for(Vector<Object> row: res){
            for(int i = 0; i < row.size(); i++){
                String content = row.elementAt(i).toString();
                int len = content.length();
                for(int j = 0; j < max_strlen[i] - len + 1; j++){
                    System.out.print(' ');
                }
                System.out.print(content);
            }
            System.out.println();
        }
    }

    public void close(){
        try {
            if(conn == null || conn.isClosed()) return;
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void test_select(SqlManager sqlManager){
        ResultSet rs = sqlManager.query("SELECT symbol, scientific_name, common_name FROM usdaplant LIMIT 100;");
        print_result(sqlManager.resultsetToArray(rs));
    }

    public static void test_prepareStatement(SqlManager sqlManager){
        String sql = "SELECT symbol, scientific_name, common_name FROM usdaplant WHERE symbol LIKE ? LIMIT 10;";
        ResultSet rs = null;
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = sqlManager.conn.prepareStatement(sql);
            preparedStatement.setString(1, "t%");
            rs = preparedStatement.executeQuery();
            print_result(sqlManager.resultsetToArray(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(rs != null) rs.close();
                if(preparedStatement != null) preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void test_insert_prepareStatement(SqlManager sqlManager){
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            preparedStatement = sqlManager.conn.prepareStatement("INSERT INTO usdaplant(symbol, scientific_name, common_name) VALUES (?, ?, ?);", Statement.RETURN_GENERATED_KEYS);
            String[] paraVal = {"THP088", "Thihnonym_kysho", "short grass"};
            for (int i = 0; i < paraVal.length; i++){
                preparedStatement.setString(i + 1, paraVal[i]);
            }
            int rowAffected = preparedStatement.executeUpdate();
            if(rowAffected == 1){
                rs = preparedStatement.getGeneratedKeys();
                while(rs.next()){
                    System.out.println("Insert symbol" + rs.getObject(1).toString() + "successfully.");
                }
            }else{
                System.out.println("Insert failed.");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                if(preparedStatement != null) preparedStatement.close();
                if(rs != null) rs.close();
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public static void test_transaction(SqlManager sqlManager){
        Statement statement = null;
        try {
            sqlManager.conn.close();
            sqlManager.conn = DriverManager.getConnection(sqlManager.url, sqlManager.user, sqlManager.password);
            sqlManager.conn.setAutoCommit(false);
            statement = sqlManager.conn.createStatement();
            statement.execute("INSERT INTO usdaplant(symbol, scientific_name, common_name) VALUES('ABAF', 'abaf', 'abaf_common');");
            statement.execute("INSERT INTO usdaplant(symbol, scientific_name, common_name) VALUES('ABAF2', 'abaf2', 'abaf_common2');");
            statement.execute("DELETE FROM usdaplant WHERE symbol = 'ABAF2' OR symbol = 'ABAF';");
            sqlManager.conn.commit();
        } catch (SQLException e) {
            try {
                sqlManager.conn.rollback();
            } catch (SQLException e1) {
                System.out.println(e1.getMessage());
            }
            System.out.println(e.getMessage());
        } finally {
            try{
                if(statement != null) statement.close();
            }catch (SQLException e){
                System.out.println(e.getMessage());
            }
        }
    }

    public static void test_storeproc(SqlManager sqlManager){
        CallableStatement cs = null;
        ResultSet rs = null;
        try{
            sqlManager.conn.close();
            sqlManager.conn = DriverManager.getConnection(sqlManager.url, sqlManager.user, sqlManager.password);
            cs = sqlManager.conn.prepareCall("{ call proc(?) }");
            cs.setString(1, "ABBA");
            rs = cs.executeQuery();
            print_result(resultsetToArray(rs));
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }finally{
            try {
                if(rs != null) rs.close();
                if(cs != null) cs.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public static void test_blob(SqlManager sqlManager){
        PreparedStatement statement = null;
        FileInputStream fis = null;
        try {
            statement = sqlManager.conn.prepareStatement("INSERT INTO usdaplant(symbol, testblob) VALUES(?, ?);");
            fis = new FileInputStream("/Users/apple/Desktop/1.pdf");
            statement.setString(1, "ZZZZ");
            statement.setBinaryStream(2, fis);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                 if(statement != null) statement.close();
                 if(fis != null)       fis.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (IOException e2){
                e2.printStackTrace();
            }

        }
    }

    public static void main(String[] args){
        SqlManager sqlManager = new SqlManager("jdbc:mysql://172.31.34.145:3306/db15301163", "15301163", "15301163");
        sqlManager.connect();

        //test_select(sqlManager);
        //test_prepareStatement(sqlManager);
        //test_insert_prepareStatement(sqlManager);
        //test_transaction(sqlManager);
        //test_storeproc(sqlManager);
        test_blob(sqlManager);
        sqlManager.close();
    }
}
